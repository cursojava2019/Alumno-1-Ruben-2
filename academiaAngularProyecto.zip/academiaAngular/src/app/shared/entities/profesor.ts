export class Profesor {

	constructor(
		public id: number,
	    public nombre: string,
	    public apellido1: string,
	    public apellido2: string,
	    public correo: string,
	    public nif: string,
	    public titulacion: string,
	    public telefono: string) {
	}
}
